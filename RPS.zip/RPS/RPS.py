from collections import Counter
import random

def player(prev_play, opponent_history=[]):
    """
    Strategy:
    1. Track opponent's previous moves.
    2. Use frequency analysis to counter their most common move.
    3. Detect repeated patterns (3 same moves in a row) and counter.
    4. Add small randomness to avoid being predictable.
    """
    if prev_play:
        opponent_history.append(prev_play)
    
    # First move
    if not opponent_history:
        return "R"
    
    # Frequency analysis
    counts = Counter(opponent_history)
    most_common = counts.most_common(1)[0][0]
    counter_move = {"R": "P", "P": "S", "S": "R"}[most_common]
    
    # Pattern detection: repeated move 3 times
    if len(opponent_history) >= 3:
        last3 = opponent_history[-3:]
        if last3[0] == last3[1] == last3[2]:
            counter_move = {"R": "P", "P": "S", "S": "R"}[last3[-1]]
    
    # Small randomness
    if random.random() < 0.05:
        counter_move = random.choice(["R", "P", "S"])
    
    return counter_move
