import random

# Example bots
def quincy(prev=""): 
    return random.choice(["R", "P", "S"])
def dee(prev=""): 
    return random.choice(["R", "P", "S"])
def kyle(prev=""): 
    return random.choice(["R", "P", "S"])
def lexi(prev=""): 
    return random.choice(["R", "P", "S"])

# Simple play function
def play(player1, player2, num_games=100, verbose=False):
    score1 = 0
    score2 = 0
    for _ in range(num_games):
        move1 = player1(player2.prev if hasattr(player2, "prev") else "")
        move2 = player2(player1.prev if hasattr(player1, "prev") else "")
        # Save last moves
        player1.prev = move1
        player2.prev = move2
        # Determine winner
        if move1 == move2:
            pass
        elif (move1, move2) in [("R", "S"), ("P", "R"), ("S", "P")]:
            score1 += 1
        else:
            score2 += 1
        if verbose:
            print(f"Player1: {move1}  Player2: {move2}")
    print(f"Final score: Player1 {score1} - Player2 {score2}")
