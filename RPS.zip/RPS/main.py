import os
print("Current working directory:", os.getcwd())
from RPS_game import play, quincy, dee, kyle, lexi
from RPS import player

# Play 1000 games against each bot
print("Playing against Quincy:")
play(player, quincy, 1000, verbose=True)

print("\nPlaying against Dee:")
play(player, dee, 1000, verbose=True)

print("\nPlaying against Kyle:")
play(player, kyle, 1000, verbose=True)

print("\nPlaying against Lexi:")
play(player, lexi, 1000, verbose=True)

